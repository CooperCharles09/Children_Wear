


<?php $__env->startSection('admin'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h3 class="mt-5 text-success d-inline-block">Students Marks Grade Details </h3>
                <button type="button" class="btn btn-outline-success " style="margin-left: 50%;" data-toggle="modal"
                    data-target="#gradeModal">
                    Enter Grade
            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="gradeModal" tabindex="-1" role="dialog" aria-labelledby="gradeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="gradeModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <form action="<?php echo e(route('gradesave.data')); ?>" mathod="get">
                                <?php echo csrf_field(); ?>
                                <div class="col-sm-12">

                                    <label for="class" class=" ml-3 mt-1  ">Enter Grade:</label>
                                    <input name="Grade" class="ml-2 form-control mb-3"type="text">

                                    <label for="class" class=" ml-3 mt-1  ">Start Marks:</label>
                                    <input name="Star_Mark" class="ml-2 form-control mb-3"type="number">

                                    <label for="class" class=" ml-3 mt-1  ">End Marks:</label>
                                    <input name="End_Mark" class="ml-2 form-control mb-3"type="text">

                                    <label for="class" class=" ml-3 mt-1  ">Remarks:</label>
                                    <input name="Remark" class="ml-2 form-control mb-3"type="text">
                                    <input type="submit" value="Save" class="btn btn-primary">

                                </div>
                            </form>

                        </div>
                    </div>

                </div>
               
            </div>
        </div>
    </div>
    <div class="container">
        <table class="table mt-5">
            <thead>
                <tr class="bg-success">
                    <th scope="col">Sr No.</th>
                    <th scope="col">Grade </th>
                    <th scope="col">Start Marks </th>
                    <th scope="col">End Marks </th>
                    <th scope="col">Remarks</th>
                    <th class="w-25"></th>

                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $Alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key => $All): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($Key + 1); ?></td>
                        <td><?php echo e($All->Grade); ?></td>
                        <td><?php echo e($All->Star_Mark); ?></td>
                        <td><?php echo e($All->End_Mark); ?></td>
                        <td><?php echo e($All->Remark); ?></td>

                        <td><a href="<?php echo e(route('deletegrade',$All->id)); ?>" class="btn btn-danger mr-3">Delete</a>
                            <a href="<?php echo e(route('editgrade',$All->id)); ?>" class="btn btn-primary">Update</a>
                        </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tr>


            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management\resources\views/mark/marksgrade.blade.php ENDPATH**/ ?>