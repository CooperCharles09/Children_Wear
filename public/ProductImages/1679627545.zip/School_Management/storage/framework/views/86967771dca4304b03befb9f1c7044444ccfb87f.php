<style>
    .h3 {
        font-family: cursive;

    }
</style>



<?php $__env->startSection('admin'); ?>
    <div class="container border rounded-5 shadow-lg bg-white mb-5 form-group mt-5 p-5">
        <div class="row">
            <div class="col-md-12">
                <h3 style="text-shadow: 2px 2px rgb(154, 243, 141);"
                    class="text-center text-dark mt-2 shadow-lg bg-white p-4 border">
                    Miracle Global School Student Registration </h3>
            </div>
        </div>
        <form action="<?php echo e(route('updatesave',$SRupdate->id)); ?>">
            <div class="row">
                <div class="col-md-4">
                    <label class="mt-5" for="Student Name">First Name</label>
                    <input name="Student_Name" value="<?php echo e($SRupdate->First_Name); ?>"
                        class="form-control shadow-lg bg-white rounded-3" type="text">
                </div>
                <div class="col-md-4">
                    <label class="mt-5" for="Father Name">Middle Name</label>
                    <input name="Father_Name" value="<?php echo e($SRupdate->Middle_Name); ?>"
                        class="form-control shadow-lg bg-white rounded-3" type="text">
                </div>
                <div class="col-md-4">
                    <label class="mt-5" for="Mother Name">Last Name</label>
                    <input name="Mother_Name" value="<?php echo e($SRupdate->Last_Name); ?>"
                        class="form-control shadow-lg bg-white rounded-3" type="text">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <label class="mt-5" for="Student Name">Mobile Nomber.</label>
                    <input name="MobileNo" value="<?php echo e($SRupdate->MobileNo); ?>"
                        class="form-control shadow-lg bg-white rounded-3" type="number">
                </div>

                <div class="col-md-6">
                    <label class="mt-5" for="">Gender</label>
                    <select name="Gender" value="<?php echo e($SRupdate->Gender); ?>"
                        class="form-control text-center shadow-lg bg-white rounded-3" name="Gender" id="">
                        <option <?php echo e($SRupdate->Gender == 'Male' ? 'selected' : ''); ?> name="Gender" selected value="Male">Male</option>
                        <option <?php echo e($SRupdate->Gender == 'Female' ? 'selected' : ''); ?> name="Gender" value="Feale">Female</option>
                        <option <?php echo e($SRupdate->Gender == 'Other' ? 'selected' : ''); ?> name="Gender" value="Other">Other</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <label class="mt-5" for="Father Name">Address</label>
                    <input name="Address" value="<?php echo e($SRupdate->Address); ?>" class="form-control shadow-lg bg-white rounded-3"
                        type="text">
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <label class="mt-5" for="Father Name">Class</label>
                    <select  class="form-control  shadow-lg bg-white rounded-3" name="Class"
                        id="">
                        <option disabled  class="">Class</option>
                        <?php $__currentLoopData = $Class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($SRupdate->Class == $class->Class ? 'selected' : ''); ?>><?php echo e($class->Class); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="col-md-4">
                    <label class="mt-5" for="Father Name">Year</label>
                    <select  class="form-control  shadow-lg bg-white rounded-3" name="Year"
                        id="">
                        <option disabled  class="">Year</option>
                        <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($SRupdate->Year == $year->Year ? 'selected' : ''); ?> ><?php echo e($year->Year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="col-md-4">
                    <label class="mt-5" for="E_mail">E_mail</label>
                    <input name="E_mail" value="<?php echo e($SRupdate->E_mail); ?>"
                        class="form-control shadow-lg bg-white rounded-3" type="email">
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <label class="mt-5" for="Religion">Religion</label>
                    <input name="Religion" value="<?php echo e($SRupdate->Religion); ?>"
                        class="form-control shadow-lg bg-white rounded-3" type="text">
                </div>
                <div class="col-md-4">
                    <label class="mt-5" for="D.O.B">D.O.B</label>
                    <input name="Date_Of_Birth" value="<?php echo e($SRupdate->Date_Of_Birth); ?>"
                        class="form-control shadow-lg bg-white rounded-3" type="date">
                </div>
                <div class="col-md-4">
                    <label class="mt-5" for="Profile Image">Profile Image</label>
                    <input class="form-control shadow-lg bg-white rounded-3" type="file">
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <a href="#" class="btn btn-outline-warning shadow-lg  rounded-3 form-control mt-5">Cancel</a>
                </div>
                <div class="col-md-4">
                    <a href="#" class="btn btn-outline-info form-control shadow-lg  rounded-3 mt-5">Reset</a>

                </div>
                <div class="col-md-4">
                    <button type="submit"
                        class="btn btn-outline-success form-control shadow-lg  rounded-3 mt-5">Register</button>

                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management\resources\views/StudentM/studentdetailsupdate.blade.php ENDPATH**/ ?>