

<?php $__env->startSection('admin'); ?>
    <style>

    </style>

    <section style="background-color: #eee;">
        <div class="container py-5 form-group">
            <div class="row">
                <div class="col">
                    
                </div>
            </div>
            <form action="<?php echo e(route('profileupdatesave', $Edit->id)); ?>">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                <?php if(Session()->has('loginid')): ?>
                                    <?php if($Edit->Gender == 'Male'): ?>
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYS9jDpFR5ohk8-5GwL3ADuCN7TohQW0ghTg&usqp=CAU"
                                            alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                                    <?php endif; ?>
                                    <?php if(Session()->has('loginid')): ?>
                                        <?php if($Edit->Gender == 'Female'): ?>
                                            <img src="https://www.freeiconspng.com/thumbs/female-icon/female-icon-27.png"
                                                alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Session()->has('loginid')): ?>
                                        <?php if($Edit->Gender == 'Other'): ?>
                                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS24C9Uvd6UCTeQ6_rl_mtHCwUNSASiGNf0Qw&usqp=CAU"
                                                alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <h5 class="my-3"><?php echo e($Edit->First_Name); ?> <?php echo e($Edit->Last_Name); ?></h5>
                                
                                <div class="d-flex justify-content-center mb-2">
                                    
                                    <button type="submit" class="btn btn-outline-success btn-lg ms-1">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">First Name</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input name="First_Name" value="<?php echo e($Edit->First_Name); ?>" class="form-control"
                                            type="text">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">Last Name</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input name="Last_Name" value="<?php echo e($Edit->Last_Name); ?>" class="form-control"
                                            type="text">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <p class="mb-0">Address</p>
                                    </div>
                                    <div class="col-sm-9">
                                        <input name="Address" value="<?php echo e($Edit->Address); ?>" class="form-control">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <p class="mb-0">Education</p>
                                    </div>
                                    <div class="col-sm-9">
                                        <select name="Education" value="<?php echo e($Edit->Education); ?>"
                                            class="select form-control ">

                                            <option name="Education"
                                                <?php echo e($Edit->Education == 'Undergraduate' ? 'selected' : ''); ?>>Undergraduate
                                            </option>
                                            <option name="Education"
                                                <?php echo e($Edit->Education == 'Postgraduate' ? 'selected' : ''); ?>>Postgraduate
                                            </option>

                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <p class="mb-0">Gender</p>
                                    </div>
                                    <div class="col-sm-9">
                                        <select name="Gender" value="<?php echo e($Edit->Gender); ?>" class="select form-control ">

                                            <option name="Gender" <?php echo e($Edit->Gender == 'Female' ? 'selected' : ''); ?>>Female
                                            </option>
                                            <option name="Gender" <?php echo e($Edit->Gender == 'Male' ? 'selected' : ''); ?>>Male
                                            </option>
                                            <option name="Gender" <?php echo e($Edit->Gender == 'Other' ? 'selected' : ''); ?>>Other
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">Email</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input name="E_mail" value="<?php echo e($Edit->E_mail); ?>" class="form-control"
                                            type="text">
                                    </div>
                                </div>
                                <hr>

                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">Mobile</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input name="Mobile_Nomber" value="<?php echo e($Edit->Mobile_Nomber); ?>" class="form-control"
                                            type="number">
                                    </div>
                                </div>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management\resources\views/profile/edit_profile.blade.php ENDPATH**/ ?>