  <!-- ======= Header ======= -->
  <header id="header" class="">
    <div class="container-fluid d-flex align-items-center">

      <h1 class="logo me-auto"><a href="<?php echo e(route('index')); ?>"><i class="fa-solid fa-m"></i>iracle <br> <i
        class="fa-solid fa-earth-europe"></i></i>
    <i class="fa-solid fa-s"></i>ch00l</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="" href="<?php echo e(route('Sindex')); ?>">Home</a></li>
          <li><a href="<?php echo e(route('Sabout')); ?>">About</a></li>
          <li><a href="<?php echo e(route('Scourse')); ?>">Courses</a></li>
          <li><a href="<?php echo e(route('Strainer')); ?>">Trainers</a></li>
          <li><a href="<?php echo e(route('Sevent')); ?>">Events</a></li>
          <li><a href="<?php echo e(route('Sid')); ?>">ID-Card</a></li>
          <li><a href="<?php echo e(route('Scontact')); ?>">Contact</a></li>
          <li><a href="<?php echo e(route('Sreg')); ?>">Registrations</a></li>
          <li><a class="profile " type="" href="<?php echo e(route('Sprofile')); ?>"><i style="font-size: 30px;"
            class="fa-solid fa-user"></i></a></i></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    

    </div>
  </header><!-- End Header --><?php /**PATH E:\LARAVEL\School_Management\resources\views/Smain/Sheader.blade.php ENDPATH**/ ?>