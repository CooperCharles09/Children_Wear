

<?php $__env->startSection('admin'); ?>
    <form action="<?php echo e(route('saveresult')); ?>">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">

                    <div class="row">
                        <div class="col-md-4">

                        </div>
                        <div class="col-md-4 border mt-5 pl-5 pr-5 mb-5">
                            <h1 class="mt-5 text-center text-success text-bold">Check Result Here</h1>
                            <?php if(session()->has('Value')): ?>
                                <div class="alert alert-danger"><?php echo e(session()->get('Value')); ?></div>
                            <?php endif; ?>
                            <h4 class="mt-5 ">Enter Student_id:-</h4>
                            <select class="form-control mb-3 ml-2 " name="ST_ID" id="">
                                <option disabled selected class="">Student_Id</option>
                                <?php $__currentLoopData = $Sname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student_Id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($Student_Id->ST_ID); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <span class="text-danger">
                                <?php $__errorArgs = ['Student_Id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span><br>
                            <h4 class="mt-2 ">Enter Student Class:-</h4>
                            <select class="form-control mb-3 ml-2 " name="Student_Class" id="">
                                <option disabled selected class="">Class</option>
                                <?php $__currentLoopData = $Class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($class->Class); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <span class="text-danger">
                                <?php $__errorArgs = ['Student_Year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span><br>
                            <h4 class="mt-2 ">Enter Student Year:-</h3>
                                <select name="Student_Year" class="ml-2 form-control mb-3"type="number">
                                    <option disabled selected class="">Year</option>
                                    <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($year->Year); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger">
                                    <?php $__errorArgs = ['Student_Year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span><br>
                                <button type="submit" class="btn btn-outline-success  mt-3 mb-5">Submit</button>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management (2)\School_Management\resources\views/result/result.blade.php ENDPATH**/ ?>