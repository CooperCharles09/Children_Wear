<style>
    .form-gap {
        padding-top: 70px;
    }
</style>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<div class="form-gap"></div>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="text-center">
                        <h3><i class="fa fa-lock fa-4x"></i></h3>
                        <h2 class="text-center">Forgot Password?</h2>
                        <p>You can reset your password here.</p>
                        <?php if(session()->has('Password')): ?>
                        <div class="alert alert-danger"><?php echo e(session()->get('Password')); ?></div>
                    <?php endif; ?>
                        <?php if(session()->has('E_mail')): ?>
                        <div class="alert alert-danger"><?php echo e(session()->get('E_mail')); ?></div>
                    <?php endif; ?>
                        <div class="panel-body">

                            <form id="register-form" role="form" action="<?php echo e(route('forget_success')); ?>"
                                autocomplete="off" class="form" method="get ">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['E_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i
                                                class="glyphicon glyphicon-envelope color-blue"></i></span>
                                        <input value="<?php echo e(old('E_mail')); ?>" id="email" name="E_mail" placeholder="email address"
                                            class="form-control" type="email">
                                           
                                    </div>
                                    <br>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['Mobile_Nomber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i
                                                class="glyphicon glyphicon-envelope color-blue"></i></span>
                                        <input value="<?php echo e(old('Mobile_Nomber')); ?>"  id="email" name="Mobile_Nomber" placeholder="Mobile_Nomber"
                                            class="form-control" type="number">
                                           
                                    </div>
                                    <br>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['New_Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-unlock-alt"></i></span>
                                            <input value="<?php echo e(old('New_Password')); ?>"  id="email" name="New_Password" placeholder=" New Password "
                                                class="form-control" type="number">
                                        </div>
                                        <br>
                                        <span class="text-danger">
                                            <?php $__errorArgs = ['Confirm_Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-unlock-alt"></i></span>
                                            <input value="<?php echo e(old('Confirm_Password')); ?>"  id="email" name="Confirm_Password" placeholder=" Confirm Password "
                                                class="form-control" type="number">
                                        </div>
                                </div>
                                <div class="form-group">
                                    <input name="recover-submit" class="btn btn-lg btn-primary btn-block"
                                        value="Confirm" type="submit">
                                </div>

                                <input type="hidden" class="hide" name="token" id="token" value="">
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\LARAVEL\School_Management\resources\views/admin/forgotpassword.blade.php ENDPATH**/ ?>