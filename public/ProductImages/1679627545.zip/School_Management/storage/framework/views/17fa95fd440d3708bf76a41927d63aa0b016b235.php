

<?php $__env->startSection('Sadmin'); ?>
    <section class="h-100 bg-light">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col">
                    <div class="card card-registration my-4">
                        <div class="row g-0">
                            <div class="col-xl-6 w-100  d-none d-xl-block">
                                <img class="shadow-lg p-3  bg-white rounded "
                                    src="https://images.unsplash.com/photo-1544717305-2782549b5136?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8c3R1ZGVudHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"
                                    alt="Sample photo" class="img-fluid"
                                    style="border-top-left-radius: .25rem; border-bottom-left-radius: .25rem;" />
                            </div>
                            <div class="col-xl-6 ">
                                <div class="card-body p-md-5 text-black">
                                    <h3 class="mb-5 text-uppercase">Student registration </h3>
                                    <?php if(session()->has('ID')): ?>
                                <div class="alert alert-danger"><?php echo e(session()->get('ID')); ?></div>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('regsave')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-12 mb-4">
                                                <div class="form-outline">
                                                    <label class="form-label" for="form3Example1n">Student ID</label>
                                                    <input type="text" value="<?php echo e(old('Student_ID')); ?>"
                                                        id="form3Example1n"name="Student_ID"
                                                        class="form-control form-control-lg" />
                                                    <span class="text-danger">
                                                        <?php $__errorArgs = ['Student_ID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <?php echo e($message); ?>

                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </span>
                                                 
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 mb-4">
                                                <div class="form-outline">
                                                    <label class="form-label" for="form3Example1m">First name</label>
                                                    <input type="text" value="<?php echo e(old('First_Name')); ?>"
                                                        id="form3Example1m" name="First_Name"
                                                        class="form-control form-control-lg" />
                                                    <span class="text-danger">
                                                        <?php $__errorArgs = ['First_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <?php echo e($message); ?>

                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form3Example97">Email ID</label>
                                            <input type="text" value="<?php echo e(old('E_mail')); ?>" id="form3Example97"
                                                class="form-control form-control-lg" name="E_mail" />
                                            <span class="text-danger">
                                                <?php $__errorArgs = ['E_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </span>
                                        </div>

                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form3Example97">Mobile No.</label>
                                            <input type="number" value="<?php echo e(old('Mobile_No')); ?>" id="form3Example97"
                                                class="form-control form-control-lg" name="Mobile_No" />
                                            <span class="text-danger">
                                                <?php $__errorArgs = ['Mobile_No'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </span>
                                        </div>

                                        <div class="form-outline mb-4">
                                            <label class="form-label" for="form3Example97">Password</label>
                                            <input type="number" value="<?php echo e(old('Password')); ?>" id="form3Example97"
                                                class="form-control form-control-lg" name="Password" />
                                            <span class="text-danger">
                                                <?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </span>
                                        </div>

                                        <div class="d-flex justify-content-end ">
                                            <button type="button" class="btn btn-light btn-lg">Reset all</button>
                                            <button type="submit" class="btn btn-warning btn-lg ms-2">Submit
                                                form</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Smain.Sadmin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management (2)\School_Management\resources\views/fronted/Sreg.blade.php ENDPATH**/ ?>