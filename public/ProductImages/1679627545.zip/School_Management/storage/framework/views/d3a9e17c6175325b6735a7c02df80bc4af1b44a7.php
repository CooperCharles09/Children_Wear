

<?php $__env->startSection('admin'); ?>
    <style>

    </style>

    <section style="background-color: #eee;">
        <div class="container py-5 form-group">
            <div class="row">
                <div class="col">
                    <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a class="text-dark" href="<?php echo e(route('profile')); ?>">Profile</a></li>

                            <li class="breadcrumb-item "><a href=""> Edit Profile </a></li>


                        </ol>
                    </nav>
                </div>
            </div>
            <form action="#">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp"
                                    alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                                <h5 class="my-3">John Smith</h5>
                                
                                <div class="d-flex justify-content-center mb-2">
                                    
                                    <button type="submit" class="btn btn-outline-success ms-1">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">Full Name</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input class="form-control" type="text">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <p class="mb-0">Address</p>
                                    </div>
                                    <div class="col-sm-9">
                                        <textarea class="form-control" cols="" rows=""></textarea>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">D.O.B</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input class="form-control" type="date">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <p class="mb-0">Gender</p>
                                    </div>
                                    <div class="col-sm-9">
                                        <select class="select form-control ">
                                            <option value="1"selected disabled>Gender</option>
                                            <option value="2">Female</option>
                                            <option value="3">Male</option>
                                            <option value="4">Other</option>
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">Email</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input class="form-control" type="text">
                                    </div>
                                </div>
                                <hr>

                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">Mobile</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input class="form-control" type="number">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="">Password:</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input class="form-control" type="number">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management\resources\views/edit_profile.blade.php ENDPATH**/ ?>