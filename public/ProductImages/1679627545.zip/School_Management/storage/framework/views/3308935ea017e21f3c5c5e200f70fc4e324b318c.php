


<?php $__env->startSection('admin'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h3 class="mt-5 text-success d-inline-block">Students Marks....</h3>
                <button type="button" class="btn btn-outline-success " style="margin-left: 63%;" data-bs-toggle="modal"
                    data-bs-target="#subjectModal">
                    Enter Marks.....
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="subjectModal" tabindex="-1" aria-labelledby="subjectModalLabel" aria-hidden="true">
        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="classModalLabel"
                        style="font-family: 'Courier New', Courier, monospace; text-shadow: 2px 2px rgb(154, 243, 141);">
                        Enter Student Marks</h5>
                    <button class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('markssave')); ?>">
                    <div class="modal-body">

                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-sm-12">
                                    <h5 for="class" class=" ml-3 mt-1  ">Student Id:</h5>
                                    <select class="form-control mb-3 ml-2 " name="ST_ID" id="">
                                        <option disabled selected class="">Student_Id</option>
                                        <?php $__currentLoopData = $Sname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student_Id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($Student_Id->ST_ID); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>


                                    <h5 for="class" class=" ml-3 mt-1  ">Student Name:</h5>
                                    <select class="form-control mb-3 ml-2 " name="Student_Name" id="">
                                        <option disabled selected class="">Student_Name</option>
                                        <?php $__currentLoopData = $Sname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($sname->First_Name); ?>  <?php echo e($sname->Middle_Name); ?>  <?php echo e($sname->Last_Name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <label for="class" class=" ml-3 mt-1  ">Student Class:</label>
                                    <select class="form-control mb-3 ml-2 " name="Student_Class" id="">
                                        <option disabled selected class="">Class</option>
                                        <?php $__currentLoopData = $Class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($class->Class); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>

                                    <h5 for="class" class=" ml-3 mt-1  ">Student Year:</h5>
                                    <select name="Student_Year" class="ml-2 form-control mb-3"type="number">
                                        <option disabled selected class="">Year</option>
                                        <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($year->Year); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <h5 for="class" class=" ml-3 mt-1  ">Student Subject:</h5>
                                    <select name="Student_Subject" class="ml-2 form-control mb-3"type="text">
                                        <option disabled selected class="">Subject</option>
                                        <?php $__currentLoopData = $Subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($subject->Subject); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <h5 for="class" class=" ml-3 mt-1  ">Total Marks:</h5>
                                    <input name="Total_Marks" class="ml-2 form-control mb-3"type="number">

                                    <h5 for="class" class=" ml-3 mt-1  ">Obtain Marks:</h5>
                                    <input name="Obtain_Marks" class="ml-2 form-control mb-3"type="number">


                                    <h5 for="class" class=" ml-3 mt-1  ">Student Grade:</h5>
                                    <select name="Student_Grade" class="ml-2 form-control mb-3"type="text">
                                        <option disabled selected class="">Grade</option>
                                        <?php $__currentLoopData = $Mgrade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mgrade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($mgrade->Grade); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>


                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">

                        <button type="submit" class="btn btn-primary">Save </button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    <div class="container table-responsive">
        <table class="table mt-5">
            <thead>
                <tr class="bg-success">
                    <th scope="col">Sr.No</th>
                    <th scope="col">Student id</th>
                    <th scope="col">Student Class</th>
                    <th scope="col">Student Year</th>
                    <th scope="col">Student Subject</th>
                    <th scope="col">Total Marks</th>
                    <th scope="col">Obtain Marks</th>
                    <th scope="col">Grade</th>



                    <th class=""></th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $MarkE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$All): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($All->Student_Id); ?></td>
                        <td><?php echo e($All->Student_Class); ?></td>
                        <td><?php echo e($All->Student_Year); ?></td>
                        <td><?php echo e($All->Student_Subject); ?></td>
                        <td><?php echo e($All->Total_Marks); ?></td>
                        <td><?php echo e($All->Obtain_Marks); ?></td>
                        <td><?php echo e($All->Student_Grade); ?></td>



               
                        <td>
                        
                            <a href="<?php echo e(route('markdelete', $All->id)); ?>" class="btn btn-danger">Delete</a>
                            <a href="<?php echo e(route('markupdate', $All->id)); ?>" class="btn btn-primary">Update</a>

                        </td>
               

                    </tr>




                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management (2)\School_Management\resources\views/mark/marksentry.blade.php ENDPATH**/ ?>