 <!-- ======= Header ======= -->
 <header id="header" class="fixed-top">
     <div class="container d-flex align-items-center">

         <h1 class="logo me-auto"><a href="<?php echo e(route('index')); ?>"><i class="fa-solid fa-m"></i>iracle <br> <i
                     class="fa-solid fa-earth-europe"></i></i>
                 <i class="fa-solid fa-s"></i>ch00l</a></h1>
         <!-- Uncomment below if you prefer to use an image logo -->
         <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

         <nav id="navbar" class="navbar order-last order-lg-0">

             <ul>
                 <li><a class="" href="<?php echo e(route('index')); ?>">Home</a></li>
                 <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                 <li><a href="<?php echo e(route('courses')); ?>">Courses</a></li>
                 <li class="dropdown"><a href="#"><span>Setup Profile</span> <i class="bi bi-chevron-down"></i></a>
                     <ul>
                         <li><a href="<?php echo e(route('ST_Profile')); ?>">Class </a></li>
                         <li><a href="#">Year</a></li>
                         <li><a href="#">Subject</a></li>

                     </ul>
                 </li>
                 <li><a href="<?php echo e(route('events')); ?>">Events</a></li>
                 <li><a href="<?php echo e(route('pricing')); ?>">Pricing</a></li>


                 <li class="dropdown"><a href="<?php echo e(route('ST_Management')); ?>"><span>Student Management</span> <i
                             class="bi bi-chevron-down"></i></a>
                     <ul>
                         <li><a href="#"> Registration</a></li>
                         <li><a href="#">Student Log Out</a></li>
                     </ul>
                 </li>
                 <li><a href="contact.html">Contact Us</a></li>
                 <li><a href="" class=""></a></i></li>
             </ul>
             <i class="bi bi-list mobile-nav-toggle"></i>


         </nav><!-- .navbar -->


     </div>
 </header><!-- End Header -->
<?php /**PATH E:\LARAVEL\School_Management\resources\views/main/navbar.blade.php ENDPATH**/ ?>