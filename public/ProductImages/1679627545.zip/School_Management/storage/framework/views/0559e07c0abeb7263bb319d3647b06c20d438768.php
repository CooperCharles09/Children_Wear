<style>
    .h3 {
        font-family: cursive;

    }
</style>



<?php $__env->startSection('admin'); ?>
    <div class="container border rounded-5 shadow-lg bg-white mb-5 form-group mt-5 p-5">
        <div class="row">
            <div class="col-md-12">
                <h3 style="text-shadow: 2px 2px rgb(154, 243, 141);" class="text-center text-dark mt-2 shadow-lg bg-white p-4 border">
                    Miracle Global School Student Registration </h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <label class="mt-5" for="Student Name">Student Name</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
            <div class="col-md-4">
                <label class="mt-5" for="Father Name">Father Name</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
            <div class="col-md-4">
                <label class="mt-5" for="Mother Name">Mother Name</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label class="mt-5" for="Student Name">Mobile Nomber.</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="number">
            </div>

            <div class="col-md-6">
                <label class="mt-5" for="Mother Name">Gender</label>
                <select class="form-control text-center shadow-lg bg-white rounded-3" name="Gender" id="">
                    <option selected value="Male">Male</option>
                    <option value="Feale">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <label class="mt-5" for="Father Name">Address</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <label class="mt-5" for="Class">Class</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
            <div class="col-md-4">
                <label class="mt-5" for="Year">Year</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
            <div class="col-md-4">
                <label class="mt-5" for="Subject">Subject</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <label class="mt-5" for="Religion">Religion</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
            <div class="col-md-4">
                <label class="mt-5" for="D.O.B">D.O.B</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="text">
            </div>
            <div class="col-md-4">
                <label class="mt-5" for="Profile Image">Profile Image</label>
                <input class="form-control shadow-lg bg-white rounded-3" type="file">
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <a href="#" class="btn btn-outline-warning shadow-lg  rounded-3 form-control mt-5">Cancel</a>
            </div>
            <div class="col-md-4">
                <a href="#" class="btn btn-outline-info form-control shadow-lg  rounded-3 mt-5">Reset</a>

            </div>
            <div class="col-md-4">
                <a href="#" class="btn btn-outline-success form-control shadow-lg  rounded-3 mt-5">Register</a>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management\resources\views/student_registration.blade.php ENDPATH**/ ?>