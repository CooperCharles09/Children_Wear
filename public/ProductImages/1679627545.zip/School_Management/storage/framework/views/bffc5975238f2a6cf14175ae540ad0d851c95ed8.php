

<?php $__env->startSection('admin'); ?>
    <main id="main">
        <!-- ======= Breadcrumbs ======= -->
        <div class="breadcrumbs" data-aos="fade-in">
            <div class="container">
                <h2>About Us</h2>
                <p>Est dolorum ut non facere possimus quibusdam eligendi voluptatem. Quia id aut similique quia voluptas sit
                    quaerat debitis. Rerum omnis ipsam aperiam consequatur laboriosam nemo harum praesentium. </p>
            </div>
        </div><!-- End Breadcrumbs -->

        <!-- ======= About Section ======= -->
       <!-- End Hero -->
    
        <main id="main">
    
            <!-- ======= About Section ======= -->
            <section id="about" class="about">
                <div class="container" data-aos="fade-up">
    
                    <div class="row">
                        <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
                            <img src="https://images.unsplash.com/photo-1594608661623-aa0bd3a69d98?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTV8fHNjaG9vbHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"
                                class="img-fluid" alt="">
                        </div>
                        <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                            <h1 class="logo me-auto"><a href="<?php echo e(route('index')); ?>"><i class="fa-solid fa-m"></i>iracle <br> <i
                                class="fa-solid fa-earth-europe"></i></i>
                            <i class="fa-solid fa-s"></i>ch00l</a></h1>
                            <p class="fst-italic">
                                The first day of school is memorable and eventful for every child. Children are quite excited
                                and nervous about going to school and meeting new people. <b> The first day of school quotes will
                                take you down memory lane and bring back the good old memories.</b> While some children get
                                delighted to experience the new environment and make new friends, others cry their hearts out at
                                the sight of their parents leaving them all alone.
    
    
                            </p>
                            <ul>
                                <li><i class="bi bi-check-circle"></i> <b> “You can teach a student a lesson for a day; but if you
                                    can teach him to learn by creating curiosity, he will continue the learning process as long
                                    as he lives.”</b>
                                    <br> <u> -Clay P. Bedford.</u>
                                </li>
                                <li><i class="bi bi-check-circle"></i><b> “A teacher affects eternity; he can never tell where his
                                    influence stops.”</b>
                                    <br> <u class="mr-5"> -Henry B. Adams</u>
                                </li>
                                <li><i class="bi bi-check-circle"></i><b> Intelligence plus character-that is the goal of true
                                    education.”</b>
                                    <br>
                                    <u>-Martin Luther King Jr.</u>
                                </li>
                            </ul>
                      
    
                        </div>
                    </div>
    
                </div>
            </section><!-- End About Section -->

        <!-- ======= Counts Section ======= -->
          <!-- ======= Counts Section ======= -->
      <section id="counts" class="counts section-bg">
        <div class="container">
  
          <div class="row counters">
  
            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="1232" data-purecounter-duration="1" class="purecounter"></span>
              <p>Students</p>
            </div>
  
            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="64" data-purecounter-duration="1" class="purecounter"></span>
              <p>Courses</p>
            </div>
  
            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="42" data-purecounter-duration="1" class="purecounter"></span>
              <p>Events</p>
            </div>
  
            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1" class="purecounter"></span>
              <p>Trainers</p>
            </div>
  
          </div>
  
        </div>
      </section><!-- End Counts Section -->

        <!-- ======= Testimonials Section ======= -->
        <section id="testimonials" class="testimonials">
            <div class="container" data-aos="fade-up">

                <div class="section-title">

                    <p>About For Us</p>
                </div>

                <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
                    <div class="swiper-wrapper">

                        <div class="swiper-slide">
                            <div class="testimonial-wrap">
                                <div class="testimonial-item">
                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/A._P._J._Abdul_Kalam.jpg/330px-A._P._J._Abdul_Kalam.jpg"
                                        class="testimonial-img" alt="">
                                    <h3>A. P. J. Abdul Kalam</h3>
                                    <h4> President Of India</h4>
                                    <p>
                                        <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                        Avul Pakir Jainulabdeen Abdul Kalam was an Indian aerospace scientist and statesman
                                        who served as the 11th
                                        President of India from 2002 to 2007 <a
                                            href="https://en.wikipedia.org/wiki/A._P._J._Abdul_Kalam">More Information</a>
                                        <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                    </p>
                                </div>
                            </div>
                        </div><!-- End testimonial item -->

                        <div class="swiper-slide">
                            <div class="testimonial-wrap">
                                <div class="testimonial-item">
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLatLSG50DK7uO2pzcrsoWpHHpi6k8jOY002NGQkPCk6rGCYdm_bNpYUeKZWqeTDRWG14&usqp=CAU"class="testimonial-img"
                                        alt="">
                                    <h3>Neeraj Chopra</h3>
                                    <h4>Winner Of World Olympic Champion</h4>
                                    <p>
                                        <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                        Neeraj Chopra (born 24 December 1997) is an Indian track and field athlete who is
                                        the reigning Olympic champion and world championship silver medalist in javelin
                                        throw.<a href="https://en.wikipedia.org/wiki/Neeraj_Chopra">More Information</a>
                                        <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                    </p>
                                </div>
                            </div>
                        </div><!-- End testimonial item -->

                        <div class="swiper-slide">
                            <div class="testimonial-wrap">
                                <div class="testimonial-item">
                                    <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img"
                                        alt="">
                                    <h3>Jena Karlis</h3>
                                    <h4>Store Owner</h4>
                                    <p>
                                        <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                        Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem
                                        veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint
                                        minim.
                                        <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                    </p>
                                </div>
                            </div>
                        </div><!-- End testimonial item -->

                        <div class="swiper-slide">
                            <div class="testimonial-wrap">
                                <div class="testimonial-item">
                                    <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img"
                                        alt="">
                                    <h3>Matt Brandon</h3>
                                    <h4>Freelancer</h4>
                                    <p>
                                        <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                        Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim
                                        fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem
                                        dolore labore illum veniam.
                                        <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                    </p>
                                </div>
                            </div>
                        </div><!-- End testimonial item -->

                        <div class="swiper-slide">
                            <div class="testimonial-wrap">
                                <div class="testimonial-item">
                                    <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img"
                                        alt="">
                                    <h3>John Larson</h3>
                                    <h4>Entrepreneur</h4>
                                    <p>
                                        <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                        Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster
                                        veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam
                                        culpa fore nisi cillum quid.
                                        <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                    </p>
                                </div>
                            </div>
                        </div><!-- End testimonial item -->

                    </div>
                    <div class="swiper-pagination"></div>
                </div>

            </div>
        </section><!-- End Testimonials Section -->

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management\resources\views/about.blade.php ENDPATH**/ ?>