


<?php $__env->startSection('admin'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="mt-5 text-success ">Students Details.. </h1>

            </div>
        </div>
    </div>

    </div>
    <div class="container-fluid">
        <table class="table mt-5">
            <thead>
                <tr class="bg-success">
                    <th scope="col">Student id</th>
                    <th scope="col">First_Name</th>
                    <th scope="col">Middle_Name</th>
                    <th scope="col">Last_Name</th>

                    <th scope="col">Gender</th>
                    <th scope="col">Address</th>
                    <th scope="col">Class</th>
                    <th scope="col">Year</th>
                  
                    <th scope="col">MobileNo</th>
                    <th scope="col">Religion</th>
                    <th></th>
                    
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $Alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $All): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($All ->ST_ID); ?></td>
                        <td><?php echo e($All->First_Name); ?></td>
                        <td><?php echo e($All->Middle_Name); ?></td>
                        <td><?php echo e($All->Last_Name); ?></td>

                        <td><?php echo e($All->Gender); ?></td>
                        <td><?php echo e($All->Address); ?></td>
                        <td><?php echo e($All->Class); ?></td>
                        <td><?php echo e($All->Year); ?></td>
                        <td><?php echo e($All->MobileNo); ?></td>
                        <td><?php echo e($All->Religion); ?></td>

                        

                        <td >
                      
                        <a  href="<?php echo e(route('SRdelete', $All->id)); ?>" class="btn btn-danger">Delete</a>

                        <a  href="<?php echo e(route('SRupdate', $All->id)); ?>" class="btn btn-primary">Update</a>
                    </td>
       
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\School_Management\resources\views/StudentM/studentdetails.blade.php ENDPATH**/ ?>