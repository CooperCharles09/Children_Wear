

<?php $__env->startSection('Sadmin'); ?>
    <form action="<?php echo e(route('ScheckId')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">

                    <div class="row ">
                        <div class="col-md-3">

                        </div>
                       
                        <div class="col-md-6 border border-dark mt-5 pl-5 pr-5 mb-5">
                            <h1 class="mt-5 text-center text-success text-bold">Check ID-Card Here</h1>
                            <?php if(Session()->has('Student_ID')): ?>
                                <div class="alert alert-danger"><?php echo e(session()->get('Student_ID')); ?></div>
                            <?php endif; ?>
                            <?php if(Session()->has('Password')): ?>
                                <div class="alert alert-danger"><?php echo e(session()->get('Password')); ?></div>
                            <?php endif; ?>
                            <?php if(Session()->has('MobileNo')): ?>
                                <div class="alert alert-danger"><?php echo e(session()->get('MobileNo')); ?></div>
                            <?php endif; ?>
                            <?php if(Session()->has('E_mail')): ?>
                                <div class="alert alert-danger"><?php echo e(session()->get('E_mail')); ?></div>
                            <?php endif; ?>
                            <?php if(session()->has('Value')): ?>
                                <div class="alert alert-danger"><?php echo e(session()->get('Value')); ?></div>
                            <?php endif; ?>

                            <h4 class="mt-5 ">Student ID:-</h4>
                            <input type="text" name="Student_ID" class="form-control shadow-lg bg-white rounded-3"
                                placeholder=" Enter Student ID">
                            <span class="text-danger">
                                <?php $__errorArgs = ['Student_ID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>

                            <h4 class="mt-5  ">E_mail</h4>
                            <input type="email" name="E_mail" class="form-control shadow-lg bg-white rounded-3"
                                placeholder="Enter E_mail">
                            <span class="text-danger">
                                <?php $__errorArgs = ['E_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                            <h4 class="mt-5  ">Mobile No:-</h4>
                            <input type="number" name="Mobile_No" class="form-control shadow-lg bg-white rounded-3"
                                placeholder="Enter  Number">
                            <span class="text-danger">
                                <?php $__errorArgs = ['Mobile_No'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                            <h4 class="mt-5 ">Password:-</h4>
                            <input type="password" name="Password" class="form-control shadow-lg bg-white rounded-3"
                                placeholder=" Enter Password">
                            <span class="text-danger">
                                <?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>





                            <button type="submit" class="btn btn-outline-success float-right mt-3 mb-5">Submit</button>

                        </div>
                        <div class="col-md-3"></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Smain.Sadmin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\School_Management (2)\School_Management\resources\views/fronted/Sid.blade.php ENDPATH**/ ?>