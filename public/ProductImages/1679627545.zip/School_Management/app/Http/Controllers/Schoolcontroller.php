<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Schoolcontroller extends Controller
{
    public function index()
    { 
        return view('index');
    }

  
  
    // public function ST_Management()
    // { 
    //     return view('Student_Management');
    // }
   
   
  
   
   
  

  
}
